package com.ne.samplenewars

import androidx.room.*

@Dao
interface NameDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertName(name: Name)

    @Query("SELECT * FROM names")
    suspend fun getAllNames(): List<Name>

    @Query("UPDATE names SET favorite = :isFav WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFav: Boolean)

    @Query("DELETE FROM names WHERE id = :id")
    suspend fun deleteNameById(id: Long)
}
