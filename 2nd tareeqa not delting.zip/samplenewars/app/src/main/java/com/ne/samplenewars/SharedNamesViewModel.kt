package com.ne.samplenewars

import android.app.Application
import androidx.lifecycle.*
import kotlinx.coroutines.launch

class SharedNamesViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = NamesDatabase.getDatabase(application).nameDao()
    private val _names = MutableLiveData<List<Name>>()
    val names: LiveData<List<Name>> = _names

    fun loadNames() {
        viewModelScope.launch {
            _names.postValue(dao.getAllNames())
        }
    }

    fun addName(name: String) {
        viewModelScope.launch {
            dao.insertName(Name(name = name))
            _names.postValue(dao.getAllNames())
        }
    }

    fun toggleFavorite(id: Long, isFav: Boolean) {
        viewModelScope.launch {
            dao.updateFavorite(id, isFav)
            _names.postValue(dao.getAllNames())
        }
    }
}
