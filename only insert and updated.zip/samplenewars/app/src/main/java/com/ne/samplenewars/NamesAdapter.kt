package com.ne.samplenewars

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ne.samplenewars.databinding.ItemNameBinding

class NamesAdapter :
    ListAdapter<Name, NamesAdapter.NameViewHolder>(DiffCallback()) {

    class NameViewHolder(val binding: ItemNameBinding) : RecyclerView.ViewHolder(binding.root)

    class DiffCallback : DiffUtil.ItemCallback<Name>() {
        override fun areItemsTheSame(oldItem: Name, newItem: Name) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Name, newItem: Name) = oldItem == newItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NameViewHolder {
        val binding = ItemNameBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NameViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NameViewHolder, position: Int) {
        val name = getItem(position)
        holder.binding.nameText.text = name.name
        holder.binding.heartIcon.setOnClickListener {
            holder.binding.heartIcon.isSelected = !holder.binding.heartIcon.isSelected
        }
    }
}
