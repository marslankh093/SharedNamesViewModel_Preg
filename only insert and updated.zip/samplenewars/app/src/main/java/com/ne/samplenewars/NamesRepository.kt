package com.ne.samplenewars

class NamesRepository(private val dao: NameDao) {
    suspend fun insert(name: Name) = dao.insertName(name)
    suspend fun deleteById(id: Long) = dao.deleteNameById(id)
    suspend fun getAll() = dao.getAllNames()
}
