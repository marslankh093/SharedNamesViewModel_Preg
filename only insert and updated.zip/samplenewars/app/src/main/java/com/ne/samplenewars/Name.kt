package com.ne.samplenewars

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "names")
data class Name(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)