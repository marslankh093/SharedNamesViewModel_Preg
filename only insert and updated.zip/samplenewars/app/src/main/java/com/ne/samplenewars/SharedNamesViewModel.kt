package com.ne.samplenewars

import android.app.Application
import androidx.lifecycle.*
import kotlinx.coroutines.launch

class SharedNamesViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = NamesDatabase.getDatabase(application).nameDao()
    private val repo = NamesRepository(dao)
    private val _names = MutableLiveData<List<Name>>()
    val names: LiveData<List<Name>> = _names
    fun loadNames() {
        viewModelScope.launch {
            _names.postValue(repo.getAll())
        }
    }
    fun addName(name: String) {
        viewModelScope.launch {
            repo.insert(Name(name = name))
            loadNames()
        }
    }
    fun deleteName(id: Long) {
        viewModelScope.launch {
            repo.deleteById(id)
            loadNames()
        }
    }
}
