package com.ne.samplenewars

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface NameDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertName(name: Name)
    @Query("SELECT * FROM names")
    suspend fun getAllNames(): List<Name>
    @Query("DELETE FROM names WHERE id = :id")
    suspend fun deleteNameById(id: Long)
}