package com.ne.samplenewars

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.ne.samplenewars.databinding.FragmentListBinding
import kotlinx.coroutines.launch

class BoysFragment : Fragment() {

    private lateinit var binding: FragmentListBinding
    private val viewModel: SharedNamesViewModel by activityViewModels()

    // When heart clicked → delete from DB
    private val adapter = NamesAdapter { name ->
        viewModel.deleteName(name.id)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentListBinding.inflate(inflater, container, false)
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        // Observe DB changes
        viewModel.names.observe(viewLifecycleOwner) {
            adapter.submitList(it.filter { n -> n.name.firstOrNull()?.isUpperCase() == true })
        }

        // Insert static data once
        lifecycleScope.launch {
            val dao = NamesDatabase.getDatabase(requireContext()).nameDao()
            if (dao.getAllNames().isEmpty()) {
                val sampleBoys = listOf(
                    Name(name = "Aiden"),
                    Name(name = "Ethan"),
                    Name(name = "Liam"),
                    Name(name = "Noah"),
                    Name(name = "Lucas")
                )
                sampleBoys.forEach { dao.insertName(it) }
                viewModel.loadNames()
            }
        }

        viewModel.loadNames()
        return binding.root
    }
}
