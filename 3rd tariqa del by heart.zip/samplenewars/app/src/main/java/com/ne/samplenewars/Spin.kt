package com.ne.samplenewars

import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import com.ne.samplenewars.databinding.ActivitySpinBinding
import java.util.*

class Spin : AppCompatActivity() {

    private lateinit var binding: ActivitySpinBinding
    private var selectedDays = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySpinBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupDropdown()
        setupWeekButtons()
        setupTimePicker()
    }

    private fun setupDropdown() {
        val types = listOf("Tablet", "Capsule", "Syrup", "Adhesive", "Injection")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, types)
        binding.dropdownType.setAdapter(adapter)
    }

    private fun setupWeekButtons() {
        val buttons = listOf(
            binding.btnSun, binding.btnMon, binding.btnTue, binding.btnWed,
            binding.btnThu, binding.btnFri, binding.btnSat
        )

        buttons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (selectedDays.contains(index)) {
                    selectedDays.remove(index)
                    button.alpha = 0.4f
                } else {
                    selectedDays.add(index)
                    button.alpha = 1.0f
                }
            }
        }
    }

    private fun setupTimePicker() {
        binding.timePicker.setOnClickListener {
            val cal = Calendar.getInstance()
            val timePickerDialog = TimePickerDialog(
                this,
                { _: TimePicker, hour: Int, minute: Int ->
                    binding.timePicker.setText(String.format("%02d:%02d", hour, minute))
                },
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                true
            )
            timePickerDialog.show()
        }
    }
}
